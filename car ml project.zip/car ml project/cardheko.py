import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.inspection import permutation_importance
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error, r2_score
from sklearn.model_selection import KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OrdinalEncoder

# -------------------------------------------------------------------------
# 1. Domain Feature Engineering
# -------------------------------------------------------------------------
def engineer_features(data: pd.DataFrame) -> pd.DataFrame:
    df_out = data.copy()
    df_out['km_per_year'] = df_out['km_driven'] / np.maximum(df_out['vehicle_age'], 1)
    df_out['power_per_liter'] = df_out['max_power'] / (df_out['engine'] / 1000.0)
    df_out['power_to_age_ratio'] = df_out['max_power'] / (df_out['vehicle_age'] + 1)
    df_out['mileage_displacement_index'] = df_out['mileage'] * (df_out['engine'] / 1000.0)
    return df_out

# -------------------------------------------------------------------------
# 2. Data Ingestion & Preprocessing Setup
# -------------------------------------------------------------------------
df = pd.read_csv("cardekho_dataset.csv")

drop_cols = ["Unnamed: 0", "car_name", "selling_price"]
feature_cols = [c for c in df.columns if c not in drop_cols]

X = df[feature_cols].copy()
y = df["selling_price"].copy()
y_log = np.log1p(y)

categorical_cols = ["brand", "model", "seller_type", "fuel_type", "transmission_type"]
numeric_cols = [
    "vehicle_age", "km_driven", "mileage", "engine", "max_power", "seats",
    "km_per_year", "power_per_liter", "power_to_age_ratio", "mileage_displacement_index"
]

feature_transformer = Pipeline(steps=[
    ('fe', FunctionTransformer(engineer_features)),
    ('encoder', ColumnTransformer(
        transformers=[
            ('cat', OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1), categorical_cols),
            ('num', 'passthrough', numeric_cols)
        ]
    ))
])

# -------------------------------------------------------------------------
# 3. Model Definition & 5-Fold Cross Validation
# -------------------------------------------------------------------------
cat_indices = list(range(len(categorical_cols)))
hgb_model = HistGradientBoostingRegressor(
    categorical_features=cat_indices,
    max_iter=300,
    learning_rate=0.06,
    max_leaf_nodes=45,
    min_samples_leaf=20,
    random_state=42
)

kf = KFold(n_splits=5, shuffle=True, random_state=42)
oof_preds = np.zeros(len(df))
cv_r2, cv_mape, cv_mae = [], [], []

X_transformed = feature_transformer.fit_transform(X)

for fold, (train_idx, val_idx) in enumerate(kf.split(X_transformed, y_log), 1):
    X_train, y_train = X_transformed[train_idx], y_log.iloc[train_idx]
    X_val, y_val = X_transformed[val_idx], y_log.iloc[val_idx]

    hgb_model.fit(X_train, y_train)

    val_pred = np.expm1(hgb_model.predict(X_val))
    oof_preds[val_idx] = val_pred

    actual = y.iloc[val_idx]
    cv_r2.append(r2_score(actual, val_pred))
    cv_mape.append(mean_absolute_percentage_error(actual, val_pred))
    cv_mae.append(mean_absolute_error(actual, val_pred))
    print(f"Fold {fold} | MAPE: {cv_mape[-1]*100:.2f}% | R2: {cv_r2[-1]:.4f} | MAE: INR {cv_mae[-1]:,.0f}")

print("\n--- Out-of-Fold Performance Summary ---")
print(f"Overall Mean MAPE : {np.mean(cv_mape)*100:.2f}%")
print(f"Overall Mean R2   : {np.mean(cv_r2):.4f}")
print(f"Overall Mean MAE  : INR {np.mean(cv_mae):,.0f}")

# Train final production model on full dataset
hgb_model.fit(X_transformed, y_log)

# -------------------------------------------------------------------------
# 4. Feature Importance Calculation
# -------------------------------------------------------------------------
all_feature_names = categorical_cols + numeric_cols
perm_importance = permutation_importance(hgb_model, X_transformed, y_log, n_repeats=5, random_state=42)
feat_imp = pd.Series(perm_importance.importances_mean, index=all_feature_names).sort_values(ascending=True)

# -------------------------------------------------------------------------
# 5. Production Artifact Serialization
# -------------------------------------------------------------------------
production_payload = {
    'preprocessor': feature_transformer,
    'model': hgb_model,
    'features': feature_cols
}
joblib.dump(production_payload, 'car_valuation_engine.joblib')
print("\nArtifact successfully saved: car_valuation_engine.joblib")

# -------------------------------------------------------------------------
# 6. Standalone Diagnostic Visualizations (Individual Figures)
# -------------------------------------------------------------------------
plt.style.use('seaborn-v0_8-whitegrid')

# Graph 1: Parity Plot
fig, ax = plt.subplots(figsize=(8, 6), dpi=150)
ax.scatter(y, oof_preds, alpha=0.25, color='#1f77b4', edgecolors='none', s=25)
lims = [min(y.min(), oof_preds.min()) * 0.8, max(y.max(), oof_preds.max()) * 1.2]
ax.plot(lims, lims, '--', color='#d62728', linewidth=2, label='Identity Line (Perfect Parity)')
ax.set_xscale('log')
ax.set_yscale('log')
ax.set_xlim(lims)
ax.set_ylim(lims)
ax.set_title("Parity Plot: Actual vs. Predicted Valuation (Out-of-Fold)", fontsize=13, fontweight='bold', pad=12)
ax.set_xlabel("Actual Selling Price (INR, Log Scale)", fontsize=11, labelpad=8)
ax.set_ylabel("Predicted Selling Price (INR, Log Scale)", fontsize=11, labelpad=8)
ax.legend(frameon=True, loc='upper left')
plt.tight_layout()
plt.savefig("graph1_actual_vs_predicted.png")
plt.show()

# Graph 2: Residual Error Distribution
pct_errors = ((oof_preds - y) / y) * 100
pct_errors_filtered = pct_errors[(pct_errors >= -80) & (pct_errors <= 80)]

fig, ax = plt.subplots(figsize=(8, 6), dpi=150)
sns.histplot(pct_errors_filtered, bins=45, kde=True, ax=ax, color='#2ca02c', edgecolor='white', alpha=0.6)
ax.axvline(0, color='#d62728', linestyle='--', linewidth=2, label='Zero Error Reference')
ax.axvline(np.median(pct_errors), color='#1f77b4', linestyle=':', linewidth=2, label=f'Median Bias ({np.median(pct_errors):+.2f}%)')
ax.set_title("Prediction Error Distribution (% Relative Deviation)", fontsize=13, fontweight='bold', pad=12)
ax.set_xlabel("Relative Error %: [(Pred - Actual) / Actual] * 100", fontsize=11, labelpad=8)
ax.set_ylabel("Transaction Count", fontsize=11, labelpad=8)
ax.legend(frameon=True)
plt.tight_layout()
plt.savefig("graph2_residual_distribution.png")
plt.show()

# Graph 3: Top Feature Importance
fig, ax = plt.subplots(figsize=(9, 5.5), dpi=150)
feat_imp.tail(10).plot(kind='barh', ax=ax, color='#ff7f0e', edgecolor='none')
ax.set_title("Permutation Feature Importance (5 Repetitions)", fontsize=13, fontweight='bold', pad=12)
ax.set_xlabel("Mean Drop in Log-Space Model Score (\(R^2\) Loss)", fontsize=11, labelpad=8)
ax.set_ylabel("Engineered & Base Features", fontsize=11, labelpad=8)
plt.tight_layout()
plt.savefig("graph3_feature_importance.png")
plt.show()

# Graph 4: Error Cohort Analysis by Vehicle Age
df_res = pd.DataFrame({'vehicle_age': df['vehicle_age'], 'abs_pct_error': np.abs(pct_errors)})
age_summary = df_res.groupby('vehicle_age').agg(
    median_mape=('abs_pct_error', 'median'),
    sample_count=('abs_pct_error', 'count')
).reset_index()
age_summary = age_summary[age_summary['sample_count'] >= 15]

fig, ax = plt.subplots(figsize=(9, 5.5), dpi=150)
sns.barplot(data=age_summary, x='vehicle_age', y='median_mape', ax=ax, palette='Blues_d', edgecolor='none')
ax.set_title("Valuation Stability: Median MAPE Across Vehicle Age Cohorts", fontsize=13, fontweight='bold', pad=12)
ax.set_xlabel("Vehicle Age (Years)", fontsize=11, labelpad=8)
ax.set_ylabel("Cohort Median Absolute % Error (MAPE)", fontsize=11, labelpad=8)
for p in ax.patches:
    h = p.get_height()
    if not np.isnan(h):
        ax.annotate(f"{h:.1f}%", (p.get_x() + p.get_width() / 2., h),
                    ha='center', va='bottom', fontsize=8, xytext=(0, 3), textcoords='offset points')
plt.tight_layout()
plt.savefig("graph4_cohort_error_by_age.png")
plt.show()